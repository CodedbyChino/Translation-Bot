import boto3
import os
import json

def translate_text(text, source_language_code, target_language_code):
    # Initialize the Translate client
    translate_client = boto3.client('translate', region_name='us-east-1')  # Replace 'your_region' with your AWS region
    
    try:
        # Call the translate_text method
        response = translate_client.translate_text(
            Text=text,
            SourceLanguageCode=source_language_code,
            TargetLanguageCode=target_language_code
        )
        
        # Extract and return the translated text
        translated_text = response['TranslatedText']
        return translated_text
    
    except Exception as e:
        print(f"Translation failed: {e}")
        return None

def lambda_handler(event, context):
    # Extract S3 event details
    s3_event = event['Records'][0]['s3']
    source_bucket = s3_event['bucket']['name']
    source_key = s3_event['object']['key']
    
    # Define source and target languages
    source_language = "auto"  # Auto-detect source language
    target_language = "fr"    # Example: translate to French
    
    # Initialize S3 client
    s3_client = boto3.client('s3')
    
    try:
        # Download the source text file from S3
        download_path = '/tmp/source.txt'  # Temporary file path
        s3_client.download_file(source_bucket, source_key, download_path)
        
        # Read the source text from the downloaded file
        with open(download_path, 'r', encoding='utf-8') as file:
            source_text = file.read()
        
        # Translate the source text
        translated_text = translate_text(source_text, source_language, target_language)
        
        if translated_text:
            # Upload the translated text to another S3 bucket
            target_bucket = 'recieve-text-2'  # Replace 'your_target_bucket' with your target S3 bucket name
            target_key = f'translated/{os.path.basename(source_key)}'  # Target key for translated text
            
            # Write translated text to a temporary file
            upload_path = '/tmp/translated.txt'
            with open(upload_path, 'w', encoding='utf-8') as file:
                file.write(translated_text)
            
            # Upload the translated text file to S3
            s3_client.upload_file(upload_path, target_bucket, target_key)
            
            return {
                'statusCode': 200,
                'body': json.dumps('Translation and upload successful!')
            }
        else:
            return {
                'statusCode': 500,
                'body': json.dumps('Translation failed.')
            }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
